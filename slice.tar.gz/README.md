# Pizzabot

This is a `node.js` application that takes in a string command, and outputs a directions string.

```bash
node pizzabot.js "5x5 (1, 3) (4, 4)"

# result: ENNNDEEEND
```

![Pizzabot](./pics/slice_pizzabot.jpg)

# Tests

To run the `jest` tests, use the following CLI commands:

### install

```
npm i
```

### run tests

```
npm test
```

You should see this output

![Pizzabot](./pics/pizzabot_tests.jpg)
